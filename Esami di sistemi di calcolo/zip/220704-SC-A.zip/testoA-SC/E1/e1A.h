#ifndef ES1_HEADER
#define ES1_HEADER

#include <string.h>
#include <stdlib.h>

int* count_vars(char** vars, int n);

#endif